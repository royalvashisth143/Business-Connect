import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { UserRole } from '../../types';
import { X, ShieldCheck, Sparkles, Mail, Lock, UserPlus } from 'lucide-react';

const roleOptions: { role: UserRole; label: string }[] = [
  { role: 'buyer', label: 'Buyer' },
  { role: 'seller', label: 'Seller / MSME' },
  { role: 'manufacturer', label: 'Manufacturer' },
  { role: 'retailer', label: 'Retailer' },
  { role: 'wholesaler', label: 'Wholesaler' },
  { role: 'supplier', label: 'Supplier' },
  { role: 'business_owner', label: 'Business Owner' },
];

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, setIsAuthModalOpen, loginWithGoogle, loginWithEmail, registerWithEmail, resetPassword } = useApp();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  if (!isAuthModalOpen) return null;

  const run = async (fn: () => Promise<void>) => {
    setBusy(true); setMessage('');
    try { await fn(); setIsAuthModalOpen(false); }
    catch (e) { setMessage(e instanceof Error ? e.message.replace('Firebase: ', '') : 'Authentication failed. Please try again.'); }
    finally { setBusy(false); }
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || (mode === 'register' && !name)) return;
    void run(() => mode === 'login' ? loginWithEmail(email, password) : registerWithEmail(email, password, role, name));
  };

  const forgot = () => {
    if (!email) { setMessage('Please enter your email first.'); return; }
    void run(async () => { await resetPassword(email); setMessage('Password reset email sent.'); });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white dark:bg-[#18221C] rounded-3xl max-w-md w-full my-6 shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden">
        <div className="p-6 bg-gradient-to-r from-[#0D5F38] to-[#16834A] text-white flex items-start justify-between">
          <div>
            <div className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-white/20 text-[11px] font-bold mb-1"><Sparkles className="w-3.5 h-3.5 text-amber-300" /> Secure Access</div>
            <h2 className="text-xl font-extrabold">BUSINESS CONNECT</h2>
            <p className="text-xs text-white/90 mt-0.5">Real Firebase account login</p>
          </div>
          <button onClick={() => setIsAuthModalOpen(false)} className="p-1 rounded-full bg-black/30 hover:bg-black/50"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-2 p-1 bg-gray-100 dark:bg-[#101713] rounded-xl">
            <button onClick={() => setMode('login')} className={`py-2 rounded-lg text-xs font-bold ${mode === 'login' ? 'bg-white dark:bg-[#18221C] shadow' : ''}`}>Sign In</button>
            <button onClick={() => setMode('register')} className={`py-2 rounded-lg text-xs font-bold ${mode === 'register' ? 'bg-white dark:bg-[#18221C] shadow' : ''}`}><UserPlus className="inline w-3.5 h-3.5 mr-1" />Register</button>
          </div>

          <button disabled={busy} onClick={() => void run(loginWithGoogle)} className="w-full py-2.5 px-4 rounded-xl border border-gray-300 dark:border-gray-700 font-bold text-xs flex items-center justify-center gap-2 disabled:opacity-50">
            Continue with Google Account
          </button>

          <div className="flex items-center gap-3 text-gray-400 text-[11px]"><div className="flex-1 border-t" /><span>or email & password</span><div className="flex-1 border-t" /></div>

          <form onSubmit={submit} className="space-y-3">
            {mode === 'register' && <input required placeholder="Full name / Business name" value={name} onChange={e => setName(e.target.value)} className="w-full px-3 py-2 text-xs rounded-xl border bg-white dark:bg-[#101713]" />}
            <div className="relative"><Mail className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" /><input required type="email" placeholder="Business email" value={email} onChange={e => setEmail(e.target.value)} className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-white dark:bg-[#101713]" /></div>
            <div className="relative"><Lock className="absolute left-3 top-2.5 w-4 h-4 text-gray-400" /><input required type="password" minLength={6} placeholder="Password (minimum 6 characters)" value={password} onChange={e => setPassword(e.target.value)} className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border bg-white dark:bg-[#101713]" /></div>
            {mode === 'register' && <select value={role} onChange={e => setRole(e.target.value as UserRole)} className="w-full px-3 py-2 text-xs rounded-xl border bg-white dark:bg-[#101713]">{roleOptions.map(o => <option key={o.role} value={o.role}>{o.label}</option>)}</select>}
            <button disabled={busy} type="submit" className="w-full py-2.5 rounded-xl bg-[#16834A] text-white font-bold text-xs disabled:opacity-50">{busy ? 'Please wait…' : mode === 'login' ? 'Sign In Securely' : 'Create Account'}</button>
          </form>

          {mode === 'login' && <button onClick={forgot} className="w-full text-xs text-[#16834A] font-semibold">Forgot password?</button>}
          {message && <div className="text-xs rounded-xl bg-red-50 text-red-700 p-3 break-words">{message}</div>}
          <div className="text-[10px] text-gray-500 flex gap-1 items-center"><ShieldCheck className="w-3.5 h-3.5" /> Demo role buttons have been removed from production login.</div>
        </div>
      </div>
    </div>
  );
};
